from mongo_manager import BancoDadosHelper 
import sys

def menu():
    print("\n=== MENU MONGO ===")
    print("1 - Listar bancos de dados")
    print("2 - Listar coleções de um banco")
    print("3 - Criar coleção em um banco")
    print("4 - Sair")
    return input("Escolha uma opção: ")

def main():
    try:
        helper = BancoDadosHelper()
    except Exception as e:
        print(f"Erro ao conectar no MongoDB: {e}")
        sys.exit(1)

    while True:
        opcao = menu()

        if opcao == "1":
            bancos = helper.listar_bancos_disponiveis()
            print("\nBancos disponíveis:")
            for b in bancos:
                print(f" - {b}")

        elif opcao == "2":
            nome_banco = input("Digite o nome do banco: ")
            try:
                colecoes = helper.listar_colecoes_banco(nome_banco)
                print(f"\nColeções no banco '{nome_banco}':")
                for c in colecoes:
                    print(f" - {c}")
            except Exception as e:
                print(f"Erro: {e}")

        elif opcao == "3":
            nome_banco = input("Digite o nome do banco: ")
            nome_colecao = input("Digite o nome da coleção: ")
            try:
                helper.criar_colecao(nome_colecao, nome_banco)
            except Exception as e:
                print(f"Erro: {e}")

        elif opcao == "4":
            print("Saindo... 👋")
            break
        else:
            print("Opção inválida!")

if __name__ == "__main__":
    main()
