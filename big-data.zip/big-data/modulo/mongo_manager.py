from pymongo import MongoClient
from pymongo.server_api import ServerApi
from dotenv import load_dotenv
import os

load_dotenv()

class BancoDadosHelper:
    """
    Classe para gerenciar operações básicas no MongoDB.
    Permite listar bancos, coleções e criar novas coleções.
    """

    def __init__(self, conexao_uri: str = None):
        """
        Inicializa o cliente do MongoDB usando a URI fornecida
        ou a variável de ambiente URL.
        """
        self.conexao_uri = conexao_uri or os.getenv("URL")
        if not self.conexao_uri:
            raise ValueError("URI do MongoDB não fornecida. Defina no .env ou passe como parâmetro.")
        
        self.cliente_mongo = MongoClient(self.conexao_uri, server_api=ServerApi('1'))

    def acessar_banco(self, nome_banco: str):
        """
        Retorna uma referência para o banco de dados especificado.
        """
        return self.cliente_mongo[nome_banco]

    def listar_bancos_disponiveis(self):
        """
        Retorna uma lista com os nomes de todos os bancos de dados.
        """
        return self.cliente_mongo.list_database_names()

    def listar_colecoes_banco(self, nome_banco: str):
        """
        Retorna uma lista com os nomes das coleções de um banco específico.
        """
        banco = self.acessar_banco(nome_banco)
        return banco.list_collection_names()

    def criar_colecao(self, nome_colecao: str, nome_banco: str):
        """
        Cria uma coleção no banco especificado, caso não exista.
        Retorna a coleção criada ou existente.
        """
        banco = self.acessar_banco(nome_banco)
        if nome_colecao in banco.list_collection_names():
            print(f"A coleção '{nome_colecao}' já existe no banco '{nome_banco}'.")
            return banco[nome_colecao]
        else:
            colecao = banco.create_collection(nome_colecao)
            print(f"Coleção '{nome_colecao}' criada com sucesso no banco '{nome_banco}'!")
            return colecao

